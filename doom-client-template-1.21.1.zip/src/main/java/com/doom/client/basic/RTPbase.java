package com.doom.client.basic;

import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public class RTPBase {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    private int state = 0; // 0: Idle, 1: Sent /rtp, 2: In Menu 1, 3: In Menu 2, 4: Scanning
    private long lastActionTime = 0;

    public void onTick() {
        if (!enabled || mc.player == null) return;

        // Prevention: Wait for server lag
        if (System.currentTimeMillis() - lastActionTime < 1000) return;

        switch (state) {
            case 0 -> { // Start the process
                mc.player.networkHandler.sendCommand("rtp");
                state = 1;
                lastActionTime = System.currentTimeMillis();
            }
            case 4 -> { // Scanning Mode
                if (scanForBase()) {
                    mc.player.sendMessage(Text.literal("§a[Doom] Base/Spawner Found! Stopping..."), false);
                    enabled = false; 
                } else {
                    mc.player.sendMessage(Text.literal("§c[Doom] Nothing found. Restarting RTP..."), false);
                    state = 0; // Loop back
                }
                lastActionTime = System.currentTimeMillis();
            }
        }
    }

    // This must be called from a Mixin or Event when a Screen opens
    public void onScreenOpen() {
        if (!enabled) return;

        if (mc.player.currentScreenHandler instanceof GenericContainerScreenHandler gui) {
            if (state == 1) { // Looking for Grass Block
                clickSlotByItem("grass_block");
                state = 2;
            } else if (state == 2) { // Looking for Random block
                // Click slot 15 (usually a random choice slot in RTP menus)
                mc.interactionManager.clickSlot(gui.syncId, 15, 0, SlotActionType.PICKUP, mc.player);
                state = 4; // Move to scan
                mc.player.closeHandledScreen();
            }
            lastActionTime = System.currentTimeMillis();
        }
    }

    private boolean scanForBase() {
        // Scans all loaded Block Entities in a 100-block radius
        for (BlockEntity entity : mc.world.blockEntities) {
            double dist = mc.player.getPos().distanceTo(entity.getPos().toCenterPos());
            if (dist <= 100) {
                if (entity instanceof ChestBlockEntity || entity instanceof MobSpawnerBlockEntity) {
                    return true;
                }
            }
        }
        return false;
    }

    private void clickSlotByItem(String name) {
        GenericContainerScreenHandler gui = (GenericContainerScreenHandler) mc.player.currentScreenHandler;
        for (int i = 0; i < gui.getInventory().size(); i++) {
            if (gui.getInventory().getStack(i).getItem().toString().contains(name)) {
                mc.interactionManager.clickSlot(gui.syncId, i, 0, SlotActionType.PICKUP, mc.player);
                break;
            }
        }
    }
}

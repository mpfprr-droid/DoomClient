package com.doom.client.basic;

import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class TunnelBase {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    private BlockPos targetPos = null;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. If we don't have a target, find the nearest one
        if (targetPos == null || isTargetReached()) {
            targetPos = findNearestTarget();
        }

        if (targetPos != null) {
            // 2. Look at the target (Silent Rotation)
            lookAt(targetPos);

            // 3. Automate Mining
            // We find the block currently in front of us towards the target
            BlockPos progressPos = getBlockInPath(targetPos);
            if (progressPos != null) {
                mc.interactionManager.updateBlockBreakingProgress(progressPos, mc.player.getHorizontalFacing());
                mc.player.swingHand(Hand.MAIN_HAND);
            }
        }
    }

    private BlockPos findNearestTarget() {
        BlockPos nearest = null;
        double minDistance = 100; // 100 block search radius

        // Search for Tile Entities (Chests/Spawners)
        for (BlockEntity entity : mc.world.blockEntities) {
            if (entity instanceof ChestBlockEntity || entity instanceof MobSpawnerBlockEntity) {
                double dist = mc.player.getPos().squaredDistanceTo(entity.getPos().toCenterPos());
                if (dist < minDistance * minDistance) {
                    minDistance = Math.sqrt(dist);
                    nearest = entity.getPos();
                }
            }
        }

        // Search for Debris/Netherite Blocks (Standard blocks)
        // Note: For large areas, this should be optimized with a Chunk scan
        return nearest;
    }

    private void lookAt(BlockPos pos) {
        Vec3d vec = pos.toCenterPos();
        double diffX = vec.x - mc.player.getX();
        double diffY = vec.y - (mc.player.getY() + mc.player.getStandingEyeHeight());
        double diffZ = vec.z - mc.player.getZ();
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        // Use rotation packets to keep your screen steady while the player mines
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }

    private BlockPos getBlockInPath(BlockPos target) {
        // Logic to return the block directly in front of the player's face
        // that is blocking the way to the target
        return mc.crosshairTarget instanceof net.minecraft.util.hit.BlockHitResult hit ? hit.getBlockPos() : null;
    }

    private boolean isTargetReached() {
        return targetPos != null && mc.world.getBlockState(targetPos).isAir();
    }
}

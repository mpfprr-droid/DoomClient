package com.doom.client.basic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;

public class FullBright {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    private double oldGamma = 1.0;

    public void onToggle() {
        if (mc.player == null) return;

        if (enabled) {
            // Save the current brightness
            oldGamma = mc.options.getGamma().getValue();
            // Set brightness to a high value (Java allows up to 10.0+ via code)
            mc.options.getGamma().setValue(10.0);
        } else {
            // Restore original brightness
            mc.options.getGamma().setValue(oldGamma);
        }
    }

    // Modern Minecraft (Java) requires a refresh sometimes
    public void onTick() {
        if (enabled && mc.options.getGamma().getValue() < 1.0) {
            mc.options.getGamma().setValue(10.0);
        }
    }
}

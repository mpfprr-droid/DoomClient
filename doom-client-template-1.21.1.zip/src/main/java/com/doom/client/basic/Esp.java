package com.doom.client.basic;

import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class StorageESP {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    // This is called during the Render World event
    public void onRender(MatrixStack matrices, Camera camera) {
        if (!enabled || mc.world == null) return;

        Vec3d camPos = camera.getPos();
        
        // Loop through all block entities (Chests, Shulkers, etc.)
        for (BlockEntity entity : mc.world.blockEntities) {
            if (isStorage(entity)) {
                BlockPos pos = entity.getPos();
                double x = pos.getX() - camPos.x;
                double y = pos.getY() - camPos.y;
                double z = pos.getZ() - camPos.z;

                // Draw the Tracer Line and the Box
                renderTracer(matrices, x + 0.5, y + 0.5, z + 0.5);
                renderBox(matrices, x, y, z, getStorageColor(entity));
            }
        }
    }

    private boolean isStorage(BlockEntity e) {
        return e instanceof ChestBlockEntity || e instanceof EnderChestBlockEntity || e instanceof ShulkerBoxBlockEntity;
    }

    private float[] getStorageColor(BlockEntity e) {
        if (e instanceof EnderChestBlockEntity) return new float[]{0.5f, 0f, 0.5f}; // Purple
        if (e instanceof ShulkerBoxBlockEntity) return new float[]{1f, 0f, 1f};     // Pink/Magenta
        return new float[]{1f, 0.5f, 0f}; // Orange for normal Chests
    }

    private void renderTracer(MatrixStack matrices, double x, double y, double z) {
        // Logic to draw a line from the center of the screen to the block
        // Using BufferBuilder and Tessellator (standard Java OpenGL approach)
    }

    private void renderBox(MatrixStack matrices, double x, double y, double z, float[] color) {
        // Logic to draw a 1x1 cube around the block coordinates
    }
}

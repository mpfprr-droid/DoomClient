package com.doom.client.manager;

import com.doom.client.DoomClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class KeybindManager {

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // --- COMBAT & MOVEMENT ---
            if (wasPressed(GLFW.GLFW_KEY_R)) toggle("AutoAim", DoomClient.autoAim);
            if (wasPressed(GLFW.GLFW_KEY_Y)) toggle("JumpReset", DoomClient.jumpReset);
            if (wasPressed(GLFW.GLFW_KEY_P)) toggle("PotRefill", DoomClient.potRefill);
            if (wasPressed(GLFW.GLFW_KEY_UP)) toggle("W-tap", DoomClient.wTap);
            if (wasPressed(GLFW.GLFW_KEY_DOWN)) toggle("S-Tap", DoomClient.sTap);
            if (wasPressed(GLFW.GLFW_KEY_I)) toggle("ShieldDisabler", DoomClient.shieldDisabler);
            if (wasPressed(GLFW.GLFW_KEY_L)) toggle("SilentAim", DoomClient.silentAim);
            if (wasPressed(GLFW.GLFW_KEY_K)) toggle("Strafe", DoomClient.strafe);

            // --- MACE MODULES ---
            if (wasPressed(GLFW.GLFW_KEY_COMMA)) toggle("AutoMace", DoomClient.autoMace);
            if (wasPressed(GLFW.GLFW_KEY_PERIOD)) toggle("BreachSwap", DoomClient.breachSwap);
            if (wasPressed(GLFW.GLFW_KEY_SEMICOLON)) toggle("ElytraMace", DoomClient.elytraMace);
            if (wasPressed(GLFW.GLFW_KEY_APOSTROPHE)) toggle("StunSlam", DoomClient.stunSlam);
            if (wasPressed(GLFW.GLFW_KEY_SLASH)) toggle("MaceAssist", DoomClient.maceAssist);

            // --- CRYSTAL & ANCHOR ---
            if (wasPressed(GLFW.GLFW_KEY_O)) toggle("AirAnchor", DoomClient.airAnchor);
            if (wasPressed(GLFW.GLFW_KEY_G)) toggle("AutoAnchor", DoomClient.autoAnchor);
            if (wasPressed(GLFW.GLFW_KEY_X)) toggle("DoomAnchor", DoomClient.doomAnchor);
            if (wasPressed(GLFW.GLFW_KEY_Z)) toggle("AutoCrystal", DoomClient.autoCrystal);
            if (wasPressed(GLFW.GLFW_KEY_T)) toggle("AutoTotem", DoomClient.autoTotem);
            if (wasPressed(GLFW.GLFW_KEY_B)) toggle("DoomCrystal", DoomClient.doomCrystal);
            if (wasPressed(GLFW.GLFW_KEY_M)) toggle("HitCrystal", DoomClient.hitCrystal);
            if (wasPressed(GLFW.GLFW_KEY_H)) toggle("R-clickCrystal", DoomClient.rClickCrystal);

            // --- UTILITY & VISUAL ---
            if (wasPressed(GLFW.GLFW_KEY_E)) toggle("Esp", DoomClient.esp);
            if (wasPressed(GLFW.GLFW_KEY_C)) toggle("Fullbright", DoomClient.fullbright);
            if (wasPressed(GLFW.GLFW_KEY_N)) toggle("RTPbase", DoomClient.rtpBase);
            if (wasPressed(GLFW.GLFW_KEY_U)) toggle("TunnelBase", DoomClient.tunnelBase);
        });
    }

    private static boolean wasPressed(int key) {
        return InputUtil.isKeyPressed(net.minecraft.client.MinecraftClient.getInstance().getWindow().getHandle(), key);
    }

    private static void toggle(String name, Object module) {
        try {
            java.lang.reflect.Field field = module.getClass().getField("enabled");
            boolean currentState = field.getBoolean(module);
            field.setBoolean(module, !currentState);
            
            Text message = Text.literal("§8[§cDoom§8] §f" + name + ": " + (!currentState ? "§aON" : "§cOFF"));
            net.minecraft.client.MinecraftClient.getInstance().player.sendMessage(message, true);
        } catch (Exception e) {
            // This catches if you misspelled a module variable in DoomClient
        // Inside your KeybindManager.java's init() method, add this:

if (wasPressed(GLFW.GLFW_KEY_RIGHT_SHIFT)) {
    // This opens the GUI screen
    if (!(client.currentScreen instanceof ClickGuiScreen)) {
        client.setScreen(new ClickGuiScreen());
    }
}


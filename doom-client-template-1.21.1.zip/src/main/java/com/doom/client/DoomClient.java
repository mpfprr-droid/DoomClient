package com.doom.client;

import com.doom.client.manager.KeybindManager;
import com.doom.client.sword.*;
import com.doom.client.mace.*;
import com.doom.client.crystal.*;
import com.doom.client.basic.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;

public class DoomClient implements ClientModInitializer {

    // --- SWORD MODULES ---
    public static AutoAim autoAim = new AutoAim();
    public static JumpReset jumpReset = new JumpReset();
    public static PotRefill potRefill = new PotRefill();
    public static WTap wTap = new WTap();
    public static STap sTap = new STap();
    public static ShieldDisabler shieldDisabler = new ShieldDisabler();
    public static SilentAim silentAim = new SilentAim();
    public static Strafe strafe = new Strafe();

    // --- MACE MODULES ---
    public static AutoMace autoMace = new AutoMace();
    public static BreachSwap breachSwap = new BreachSwap();
    public static ElytraMace elytraMace = new ElytraMace();
    public static StunSlam stunSlam = new StunSlam();
    public static MaceAssist maceAssist = new MaceAssist();

    // --- CRYSTAL MODULES ---
    public static AirAnchor airAnchor = new AirAnchor();
    public static AutoAnchor autoAnchor = new AutoAnchor();
    public static DoomAnchor doomAnchor = new DoomAnchor();
    public static AutoCrystal autoCrystal = new AutoCrystal();
    public static DoomCrystal doomCrystal = new DoomCrystal();
    public static HitCrystal hitCrystal = new HitCrystal();
    public static RClickCrystal rClickCrystal = new RClickCrystal();

    // --- BASIC MODULES ---
    public static AutoTotem autoTotem = new AutoTotem();
    public static Esp esp = new Esp();
    public static Fullbright fullbright = new Fullbright();
    public static RTPbase rtpBase = new RTPbase();
    public static TunnelBase tunnelBase = new TunnelBase();

    @Override
    public void onInitializeClient() {
        // Start the input listener
        KeybindManager.init();

        // Standard Tick Loop (20 times per second)
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            // Update Sword
            autoAim.onTick();
            jumpReset.onTick();
            potRefill.onTick();
            wTap.onTick();
            sTap.onTick();
            shieldDisabler.onTick();
            silentAim.onTick();
            strafe.onTick();

            // Update Mace
            autoMace.onTick();
            breachSwap.onTick();
            elytraMace.onTick();
            stunSlam.onTick();
            maceAssist.onTick();

            // Update Crystal
            airAnchor.onTick();
            autoAnchor.onTick();
            doomAnchor.onTick();
            autoCrystal.onTick();
            doomCrystal.onTick();
            hitCrystal.onTick();
            rClickCrystal.onTick();

            // Update Basic
            autoTotem.onTick();
            fullbright.onTick();
            rtpBase.onTick();
            tunnelBase.onTick();
        });

        // Specialized Render Loop (For ESP/Tracers)
        WorldRenderEvents.LAST.register(context -> {
            if (esp.enabled) {
                esp.onRender(context.matrixStack(), context.camera());
            }
        });
    }
}

package com.doom.client.crystal;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AutoAnchor {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // Check the block you are looking at
        if (mc.crosshairTarget instanceof BlockHitResult hit) {
            BlockPos pos = hit.getBlockPos();
            
            // If it's a Respawn Anchor
            if (mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR)) {
                explodeAnchor(pos, hit);
            }
        }
    }

    private void explodeAnchor(BlockPos pos, BlockHitResult hit) {
        int glowstoneSlot = findItem(Items.GLOWSTONE);
        if (glowstoneSlot != -1) {
            int oldSlot = mc.player.getInventory().selectedSlot;

            // 1. Swap to Glowstone
            mc.player.getInventory().selectedSlot = glowstoneSlot;

            // 2. Click to Charge the Anchor
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);

            // 3. Click again to Explode it (In the same tick)
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);

            // 4. Swap back to original item (usually the Anchor or Sword)
            mc.player.getInventory().selectedSlot = oldSlot;
        }
    }

    private int findItem(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }
}

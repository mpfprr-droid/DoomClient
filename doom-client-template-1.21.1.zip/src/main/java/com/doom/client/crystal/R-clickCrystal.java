package com.doom.client.crystal;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class AutoCrystal {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = true;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // Check if player is holding Right Click
        if (mc.options.useKey.isPressed()) {
            
            // Check if holding a Crystal
            if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) {
                
                // Check if looking at Obsidian or Bedrock
                if (mc.crosshairTarget instanceof BlockHitResult hit) {
                    if (mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.OBSIDIAN) || 
                        mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.BEDROCK)) {
                        
                        // INSTANT PLACEMENT: Send packet directly
                        // This ignores the 4-tick vanilla delay completely
                        mc.player.networkHandler.sendPacket(new PlayerInteractBlockC2SPacket(Hand.MAIN_HAND, hit, 0));
                        
                        // Optional: Swing hand locally for visual feedback
                        mc.player.swingHand(Hand.MAIN_HAND);
                        
                        // OPTIMIZER: Reset the internal "itemUseCooldwn" to 0
                        // (Requires AccessWidener or Mixin for the field 'itemUseCooldown' in MinecraftClient)
                        // mc.itemUseCooldown = 0; 
                    }
                }
            }
        }
    }
}

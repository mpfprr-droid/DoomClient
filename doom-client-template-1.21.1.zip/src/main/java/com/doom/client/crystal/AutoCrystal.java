package com.doom.client.crystal;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;

public class AutoCrystal {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. Check if we are looking at Obsidian or Bedrock
        if (mc.crosshairTarget instanceof BlockHitResult hit) {
            if (mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.OBSIDIAN) || 
                mc.world.getBlockState(hit.getBlockPos()).isOf(Blocks.BEDROCK)) {
                
                placeCrystal(hit);
            }
        }

        // 2. Check if we are looking at a Crystal to break it
        if (mc.crosshairTarget instanceof EntityHitResult entityHit) {
            if (entityHit.getEntity() instanceof EndCrystalEntity crystal) {
                breakCrystal(crystal);
            }
        }
    }

    private void placeCrystal(BlockHitResult hit) {
        int crystalSlot = findItem(Items.END_CRYSTAL);
        if (crystalSlot != -1) {
            int oldSlot = mc.player.getInventory().selectedSlot;
            mc.player.getInventory().selectedSlot = crystalSlot;
            
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
            
            mc.player.getInventory().selectedSlot = oldSlot;
        }
    }

    private void breakCrystal(EndCrystalEntity crystal) {
        // Swing hand and attack the crystal entity
        mc.interactionManager.attackEntity(mc.player, crystal);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private int findItem(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }
}

package com.doom.client.crystal;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public class DoomAnchor {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    // This method is called whenever you explode an anchor
    public void optimize(BlockPos pos) {
        if (!enabled || mc.world == null) return;

        // Instantly tell the client that this block is now AIR
        // This removes the "ghost block" delay from the server
        mc.world.setBlockState(pos, Blocks.AIR.getDefaultState());
        
        // This allows AirAnchor to place the next one IMMEDIATELY 
        // without waiting for the explosion animation to finish
    }
}

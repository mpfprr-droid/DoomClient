package com.doom.client.basic;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null) return;

        // 1. Check if we already have a Totem in the off-hand
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        // 2. If off-hand is empty (or has something else), find a Totem in inventory
        int totemSlot = findTotemSlot();

        if (totemSlot != -1) {
            // 3. Move the totem to the off-hand (Slot 45)
            // We use PICKUP and then click the offhand slot to swap it
            moveTotemToOffhand(totemSlot);
        }
    }

    private int findTotemSlot() {
        // Search main inventory (9-35) and hotbar (0-8)
        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                // Adjusting index for Java ScreenHandler (Hotbar is 36-44, Inv is 9-35)
                return i < 9 ? i + 36 : i;
            }
        }
        return -1;
    }

    private void moveTotemToOffhand(int slot) {
        // Java Slot 45 is the Off-hand
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, 45, 0, SlotActionType.PICKUP, mc.player);
        mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, 0, SlotActionType.PICKUP, mc.player);
    }
}

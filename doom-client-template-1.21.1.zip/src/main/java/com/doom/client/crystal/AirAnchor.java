package com.doom.client.crystal;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class AirAnchor {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    private BlockPos lastAnchorPos = null;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. If we just blew up an anchor, the block at that position will be AIR or FIRE
        if (lastAnchorPos != null) {
            if (mc.world.getBlockState(lastAnchorPos).isAir() || mc.world.getBlockState(lastAnchorPos).isOf(Blocks.FIRE)) {
                replaceAnchor(lastAnchorPos);
                lastAnchorPos = null; // Reset so we don't spam
            }
        }
    }

    // This should be called from your "Use" event (when you click an anchor)
    public void onAnchorExplode(BlockPos pos) {
        if (enabled) {
            this.lastAnchorPos = pos;
        }
    }

    private void replaceAnchor(BlockPos pos) {
        int anchorSlot = findItem(Items.RESPAWN_ANCHOR);
        if (anchorSlot != -1) {
            int oldSlot = mc.player.getInventory().selectedSlot;
            
            // Swap to anchor
            mc.player.getInventory().selectedSlot = anchorSlot;
            
            // Place the anchor at the old position
            BlockHitResult hitResult = new BlockHitResult(pos.toCenterPos(), Direction.UP, pos, false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
            
            // Swap back
            mc.player.getInventory().selectedSlot = oldSlot;
        }
    }

    private int findItem(net.minecraft.item.Item item) {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(item)) return i;
        }
        return -1;
    }
}

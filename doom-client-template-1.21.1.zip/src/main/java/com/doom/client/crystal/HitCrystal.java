package com.doom.client.crystal;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;

public class HitCrystal {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // Check if the player is looking at an entity
        if (mc.crosshairTarget instanceof EntityHitResult entityHit) {
            // Check if that entity is an End Crystal
            if (entityHit.getEntity() instanceof EndCrystalEntity crystal) {
                // Blast it instantly
                breakCrystal(crystal);
            }
        }
    }

    private void breakCrystal(EndCrystalEntity crystal) {
        // Attack the crystal
        mc.interactionManager.attackEntity(mc.player, crystal);
        mc.player.swingHand(Hand.MAIN_HAND);
        
        // Instant removal from client-side to prevent 'ghost' crystals
        crystal.discard();
    }
}

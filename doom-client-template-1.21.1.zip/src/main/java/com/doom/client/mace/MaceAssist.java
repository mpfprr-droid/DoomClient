package com.doom.client.mace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;

public class MaceAim {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    public double range = 6.0; // Slightly longer range for mace drops

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // Only aim if holding a Mace and falling more than 1.5 blocks
        if (mc.player.getMainHandStack().isOf(Items.MACE) && mc.player.fallDistance > 1.5f) {
            PlayerEntity target = getNearestPlayer();
            if (target != null) {
                faceEntity(target);
            }
        }
    }

    private PlayerEntity getNearestPlayer() {
        PlayerEntity nearest = null;
        double closestDist = range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double dist = mc.player.distanceTo(player);
            if (dist <= closestDist) {
                closestDist = dist;
                nearest = player;
            }
        }
        return nearest;
    }

    private void faceEntity(PlayerEntity entity) {
        Vec3d targetPos = entity.getEyePos();
        Vec3d playerPos = mc.player.getEyePos();
        double diffX = targetPos.x - playerPos.x;
        double diffY = targetPos.y - playerPos.y;
        double diffZ = targetPos.z - playerPos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }
}

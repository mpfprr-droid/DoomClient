package com.doom.client.mace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class StunSlam {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // Trigger only when falling for a smash
        if (mc.player.fallDistance > 1.5f) {
            PlayerEntity target = getNearestPlayer(5.0);
            
            if (target != null) {
                // 1. Check if they are shielding
                if (target.isBlocking()) {
                    int axeSlot = findItemSlot(AxeItem.class);
                    if (axeSlot != -1) {
                        // Switch to Axe and break the shield
                        mc.player.getInventory().selectedSlot = axeSlot;
                        mc.interactionManager.attackEntity(mc.player, target);
                        mc.player.swingHand(Hand.MAIN_HAND);
                    }
                }

                // 2. Immediate swap to Mace for the Slam
                int maceSlot = findMace();
                if (maceSlot != -1) {
                    mc.player.getInventory().selectedSlot = maceSlot;
                    
                    // Attack if in range for the smash
                    if (mc.player.distanceTo(target) <= 3.2f) {
                        mc.interactionManager.attackEntity(mc.player, target);
                        mc.player.swingHand(Hand.MAIN_HAND);
                    }
                }
            }
        }
    }

    private int findMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        }
        return -1;
    }

    private int findItemSlot(Class<?> itemClass) {
        for (int i = 0; i < 9; i++) {
            if (itemClass.isInstance(mc.player.getInventory().getStack(i).getItem())) return i;
        }
        return -1;
    }

    private PlayerEntity getNearestPlayer(double range) {
        PlayerEntity nearest = null;
        double closestDist = range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double dist = mc.player.distanceTo(player);
            if (dist <= closestDist) {
                closestDist = dist;
                nearest = player;
            }
        }
        return nearest;
    }
}

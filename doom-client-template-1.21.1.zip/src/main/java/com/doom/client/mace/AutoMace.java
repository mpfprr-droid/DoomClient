package com.doom.client.mace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class AutoMace {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. Check if falling
        if (mc.player.fallDistance > 1.5f) {
            PlayerEntity target = getNearestPlayer(6.0);
            
            if (target != null) {
                // 2. Equip the best Mace
                int bestSlot = findBestMace();
                if (bestSlot != -1) mc.player.getInventory().selectedSlot = bestSlot;

                // 3. Aim at target
                faceEntity(target);

                // 4. Attack at the right moment (within 3 blocks)
                if (mc.player.distanceTo(target) <= 3.2f) {
                    mc.interactionManager.attackEntity(mc.player, target);
                    mc.player.swingHand(Hand.MAIN_HAND);
                }
            }
        }
    }

    private int findBestMace() {
        int bestSlot = -1;
        int highestDensity = -1;

        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.MACE)) {
                // Get Density level (this checks the new 1.21 component system)
                int densityLevel = EnchantmentHelper.getLevel(mc.world.getRegistryManager().getWrapperOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT).getOrThrow(net.minecraft.enchantment.Enchantments.DENSITY), stack);
                
                if (densityLevel > highestDensity) {
                    highestDensity = densityLevel;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    private PlayerEntity getNearestPlayer(double range) {
        PlayerEntity nearest = null;
        double closestDist = range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double dist = mc.player.distanceTo(player);
            if (dist <= closestDist) {
                closestDist = dist;
                nearest = player;
            }
        }
        return nearest;
    }

    private void faceEntity(PlayerEntity entity) {
        Vec3d targetPos = entity.getEyePos();
        Vec3d playerPos = mc.player.getEyePos();
        double diffX = targetPos.x - playerPos.x;
        double diffY = targetPos.y - playerPos.y;
        double diffZ = targetPos.z - playerPos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));
        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }
}

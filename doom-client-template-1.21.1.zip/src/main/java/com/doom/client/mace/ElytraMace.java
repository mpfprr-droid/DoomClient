package com.doom.client.mace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;

public class ElytraSwap {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. Detect if we are launched high into the air
        if (mc.player.fallDistance > 1.5f || mc.player.getVelocity().y > 0.5) {
            PlayerEntity target = getNearestPlayer(15.0);
            
            if (target != null) {
                // 2. If high enough, equip Elytra to glide toward target
                if (mc.player.getY() > target.getY() + 3) {
                    equipItem(Items.ELYTRA);
                    if (!mc.player.isFallFlying()) {
                        // Send jump packet to start gliding
                        mc.player.jump(); 
                    }
                }

                // 3. Aim at target while gliding
                faceEntity(target);

                // 4. At the right moment, swap back to Chestplate to "drop" and smash
                if (mc.player.distanceTo(target) <= 4.0f) {
                    equipItem(Items.NETHERITE_CHESTPLATE); // Or DIAMOND_CHESTPLATE
                    
                    // 5. Final Mace Smash
                    int maceSlot = findBestMace();
                    if (maceSlot != -1) {
                        mc.player.getInventory().selectedSlot = maceSlot;
                        if (mc.player.distanceTo(target) <= 3.2f) {
                            mc.interactionManager.attackEntity(mc.player, target);
                            mc.player.swingHand(Hand.MAIN_HAND);
                        }
                    }
                }
            }
        }
    }

    private void equipItem(net.minecraft.item.Item targetItem) {
        if (mc.player.getEquippedStack(EquipmentSlot.CHEST).isOf(targetItem)) return;

        for (int i = 0; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).isOf(targetItem)) {
                // Swap inventory item with Chest slot (Slot 6 in Minecraft's PlayerScreenHandler)
                mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, i < 9 ? i + 36 : i, 6, SlotActionType.SWAP, mc.player);
                break;
            }
        }
    }

    private int findBestMace() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.MACE)) return i;
        }
        return -1;
    }

    private PlayerEntity getNearestPlayer(double range) {
        PlayerEntity nearest = null;
        double closestDist = range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double dist = mc.player.distanceTo(player);
            if (dist <= closestDist) { closestDist = dist; nearest = player; }
        }
        return nearest;
    }

    private void faceEntity(PlayerEntity entity) {
        double diffX = entity.getX() - mc.player.getX();
        double diffY = entity.getEyeY() - mc.player.getEyeY();
        double diffZ = entity.getZ() - mc.player.getZ();
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        mc.player.setYaw((float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F);
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(diffY, diffXZ)));
    }
}

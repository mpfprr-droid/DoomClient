package com.doom.client.mace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.util.Hand;

public class BreachSwap {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onAttack(PlayerEntity target) {
        if (!enabled || mc.player == null || target == null) return;

        // Only trigger if NOT doing a high-damage smash (fall < 1.5)
        if (mc.player.fallDistance < 1.5f) {
            int swordSlot = findItemSlot(SwordItem.class);
            int breachMaceSlot = findBreachMace();

            if (breachMaceSlot != -1 && swordSlot != -1) {
                // 1. Swap to Breach Mace
                mc.player.getInventory().selectedSlot = breachMaceSlot;

                // 2. Perform the attack (Ignores armor)
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);

                // 3. Instantly swap back to Sword for speed/combos
                mc.player.getInventory().selectedSlot = swordSlot;
            }
        }
    }

    private int findBreachMace() {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = mc.player.getInventory().getStack(i);
            if (stack.isOf(Items.MACE)) {
                // Check for Breach enchantment level
                int breachLevel = EnchantmentHelper.getLevel(mc.world.getRegistryManager().getWrapperOrThrow(net.minecraft.registry.RegistryKeys.ENCHANTMENT).getOrThrow(net.minecraft.enchantment.Enchantments.BREACH), stack);
                if (breachLevel > 0) return i;
            }
        }
        return -1;
    }

    private int findItemSlot(Class<?> itemClass) {
        for (int i = 0; i < 9; i++) {
            if (itemClass.isInstance(mc.player.getInventory().getStack(i).getItem())) return i;
        }
        return -1;
    }
}

package com.doom.client.gui;

import com.doom.client.DoomClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class ClickGuiScreen extends Screen {
    private String selectedCategory = "sword";
    private TextFieldWidget searchBar;
    private final int widthBox = 400;
    private final int heightBox = 250;

    public ClickGuiScreen() {
        super(Text.literal("Doom GUI"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2 - widthBox / 2;
        int centerY = this.height / 2 - heightBox / 2;

        // Search bar at the top
        searchBar = new TextFieldWidget(textRenderer, centerX + 110, centerY + 10, 280, 20, Text.literal(""));
        searchBar.setPlaceholder(Text.literal("Search..."));
        this.addSelectableChild(searchBar);
        searchBar.setFocused(true);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Draw dark background overlay
        this.renderBackground(context, mouseX, mouseY, delta);

        int centerX = this.width / 2 - widthBox / 2;
        int centerY = this.height / 2 - heightBox / 2;

        // 1. Main Box (Dark Gray)
        context.fill(centerX, centerY, centerX + widthBox, centerY + heightBox, 0xDD101010);
        
        // 2. Sidebar (Slightly Lighter)
        context.fill(centerX, centerY, centerX + 100, centerY + heightBox, 0xDD1A1A1A);

        // 3. Draw Search Bar
        searchBar.render(context, mouseX, mouseY, delta);

        // 4. Draw Categories
        String[] categories = {"sword", "mace", "crystal", "basic"};
        for (int i = 0; i < categories.length; i++) {
            boolean isSelected = categories[i].equalsIgnoreCase(selectedCategory);
            int yPos = centerY + 40 + (i * 25);
            
            // Highlight selected category
            if (isSelected) context.fill(centerX, yPos - 5, centerX + 100, yPos + 15, 0x44FF0000);
            
            context.drawText(textRenderer, categories[i].toUpperCase(), centerX + 10, yPos, isSelected ? 0xFFFF0000 : 0xFFFFFFFF, false);
        }

        // 5. Draw Modules List
        renderModuleList(context, centerX + 110, centerY + 40, mouseX, mouseY);

        super.render(context, mouseX, mouseY, delta);
    }

    private void renderModuleList(DrawContext context, int startX, int startY, int mouseX, int mouseY) {
        String query = searchBar.getText().toLowerCase();
        Object[] modulesToDisplay = getModules(selectedCategory);
        int yOffset = 0;

        for (Object mod : modulesToDisplay) {
            String name = mod.getClass().getSimpleName();
            
            // Search Filter
            if (!query.isEmpty() && !name.toLowerCase().contains(query)) continue;

            boolean enabled = getEnabled(mod);
            int color = enabled ? 0xFF00FF00 : 0xFFBBBBBB; // Green if ON, Gray if OFF

            // Hover effect
            boolean isHovered = mouseX > startX && mouseX < startX + 280 && mouseY > startY + yOffset && mouseY < startY + yOffset + 12;
            if (isHovered) context.fill(startX - 2, startY + yOffset - 2, startX + 280, startY + yOffset + 10, 0x22FFFFFF);

            context.drawText(textRenderer, name, startX, startY + yOffset, color, true);
            yOffset += 18;
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int centerX = this.width / 2 - widthBox / 2;
        int centerY = this.height / 2 - heightBox / 2;

        // Category Clicking
        if (mouseX > centerX && mouseX < centerX + 100) {
            String[] cats = {"sword", "mace", "crystal", "basic"};
            for (int i = 0; i < cats.length; i++) {
                int yPos = centerY + 40 + (i * 25);
                if (mouseY > yPos - 5 && mouseY < yPos + 15) {
                    selectedCategory = cats[i];
                    return true;
                }
            }
        }

        // Module Toggling
        int startX = centerX + 110;
        int startY = centerY + 40;
        Object[] modules = getModules(selectedCategory);
        int yOffset = 0;
        for (Object mod : modules) {
            if (mouseY > startY + yOffset && mouseY < startY + yOffset + 12 && mouseX > startX) {
                toggleModule(mod);
                return true;
            }
            yOffset += 18;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private Object[] getModules(String cat) {
        return switch (cat.toLowerCase()) {
            case "sword" -> new Object[]{DoomClient.autoAim, DoomClient.jumpReset, DoomClient.potRefill, DoomClient.wTap, DoomClient.sTap, DoomClient.shieldDisabler, DoomClient.silentAim, DoomClient.strafe};
            case "mace" -> new Object[]{DoomClient.autoMace, DoomClient.breachSwap, DoomClient.elytraMace, DoomClient.stunSlam, DoomClient.maceAssist};
            case "crystal" -> new Object[]{DoomClient.airAnchor, DoomClient.autoAnchor, DoomClient.doomAnchor, DoomClient.autoCrystal, DoomClient.doomCrystal, DoomClient.hitCrystal, DoomClient.rClickCrystal};
            case "basic" -> new Object[]{DoomClient.autoTotem, DoomClient.esp, DoomClient.fullbright, DoomClient.rtpBase, DoomClient.tunnelBase};
            default -> new Object[0];
        };
    }

    private boolean getEnabled(Object mod) {
        try { return mod.getClass().getField("enabled").getBoolean(mod); } catch (Exception e) { return false; }
    }

    private void toggleModule(Object mod) {
        try {
            boolean current = mod.getClass().getField("enabled").getBoolean(mod);
            mod.getClass().getField("enabled").set(mod, !current);
        } catch (Exception ignored) {}
    }
    
    @Override
    public boolean shouldPause() { return false; } // Don't pause the game in multiplayer
}

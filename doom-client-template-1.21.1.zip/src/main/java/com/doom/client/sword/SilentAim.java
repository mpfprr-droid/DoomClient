package com.doom.client.sword;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class SilentAim {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;
    public double range = 4.5;
    
    private float lastYaw;
    private float lastPitch;

    public void onTick() {
        if (!enabled || mc.player == null || mc.world == null) return;

        // 1. Check if the player is currently moving their mouse
        // We compare current rotation to the rotation from the last tick
        boolean isMouseMoving = mc.player.getYaw() != lastYaw || mc.player.getPitch() != lastPitch;

        if (!isMouseMoving) {
            PlayerEntity target = getNearestPlayer();
            if (target != null) {
                faceEntity(target);
            }
        }

        // Update 'last' rotations for the next check
        lastYaw = mc.player.getYaw();
        lastPitch = mc.player.getPitch();
    }

    private PlayerEntity getNearestPlayer() {
        PlayerEntity nearest = null;
        double closestDist = range;
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            double dist = mc.player.distanceTo(player);
            if (dist <= closestDist) {
                closestDist = dist;
                nearest = player;
            }
        }
        return nearest;
    }

    private void faceEntity(PlayerEntity entity) {
        Vec3d targetPos = entity.getEyePos();
        Vec3d playerPos = mc.player.getEyePos();
        double diffX = targetPos.x - playerPos.x;
        double diffY = targetPos.y - playerPos.y;
        double diffZ = targetPos.z - playerPos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);

        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90F;
        float pitch = (float) -Math.toDegrees(Math.atan2(diffY, diffXZ));

        mc.player.setYaw(yaw);
        mc.player.setPitch(pitch);
    }
}

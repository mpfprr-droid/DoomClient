package com.doom.client.sword;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

public class WTap {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    // This method should be called right after an attack happens
    public void onAttack() {
        if (!enabled || mc.player == null) return;

        if (mc.player.isSprinting()) {
            // 1. Tell the server we stopped sprinting
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            
            // 2. Tell the server we started sprinting again (this creates the "Tap" effect)
            mc.player.networkHandler.sendPacket(new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
            
            // Optional: You can add a tiny delay here if the server anti-cheat is strict
        }
    }
}

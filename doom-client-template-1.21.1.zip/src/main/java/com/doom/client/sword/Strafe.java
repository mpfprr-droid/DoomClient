package com.doom.client.sword;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import java.util.Random;

public class Strafe {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private final Random random = new Random();
    public boolean enabled = false;

    public void onAttack() {
        if (!enabled || mc.player == null) return;

        // Randomly choose Left (A) or Right (D)
        boolean left = random.nextBoolean();
        boolean right = !left;

        // Send a packet telling the server we pressed the key
        // Parameters: forward (0), backward (0), left, right
        mc.player.networkHandler.sendPacket(new PlayerInputC2SPacket(0, 0, left, right));
    }
}

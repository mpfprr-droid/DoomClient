package com.doom.client.sword;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;

public class STap {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onAttack() {
        if (!enabled || mc.player == null) return;

        // We send a packet telling the server we are holding the "Back" key (S)
        // Parameters: forward (0), backward (true), left (false), right (false)
        mc.player.networkHandler.sendPacket(new PlayerInputC2SPacket(0, 1.0f, false, false));
        
        // This creates that tiny 'stutter' back that keeps you at 3.0 block distance
    }
}

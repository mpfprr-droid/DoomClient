package com.doom.client.sword;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.util.Hand;

public class ShieldDisabler {
    private static final MinecraftClient mc = MinecraftClient.getInstance();
    public boolean enabled = false;

    public void onUpdate(PlayerEntity target) {
        if (!enabled || target == null || mc.player == null) return;

        // Check if the target is currently blocking with a shield
        if (target.isBlocking()) {
            int axeSlot = findAxe();

            if (axeSlot != -1) {
                // 1. Switch to Axe
                mc.player.getInventory().selectedSlot = axeSlot;

                // 2. Attack to disable the shield
                mc.interactionManager.attackEntity(mc.player, target);
                mc.player.swingHand(Hand.MAIN_HAND);
                
                // Note: The Shield will now be on cooldown for the enemy
            }
        }
    }

    private int findAxe() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).getItem() instanceof AxeItem) {
                return i;
            }
        }
        return -1;
    }
}
